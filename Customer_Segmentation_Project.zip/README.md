# Customer Segmentation Project

## 1. Project Title
**Customer Segmentation Based on Behavior and Demographics**

## 2. Objective
The objective is to group customers with similar demographic and purchasing behavior using machine learning. K-Means clustering is used to identify customer segments that can support targeted marketing and customer analytics.

## 3. Tools & Technologies
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- Jupyter Notebook

## 4. Dataset
The included dataset contains 500 customer records with demographic and behavioral variables:
- Customer ID
- Gender
- Age
- Annual income
- Purchase frequency
- Average order value
- Website visits per month
- Discount usage percentage
- Spending score

## 5. Methodology
1. Load and inspect the dataset.
2. Check data quality and missing values.
3. Explore demographic and purchasing patterns.
4. Select relevant clustering features.
5. Standardize the numerical variables using StandardScaler.
6. Evaluate different values of K using the Elbow Method and Silhouette Score.
7. Train a K-Means clustering model.
8. Profile the resulting customer segments.
9. Visualize the segments.
10. Convert the clusters into actionable business insights.

## 6. Model
K-Means clustering was selected because it is an unsupervised learning algorithm suitable for grouping customers based on similarity. The final project uses **K = 4** based on the clustering evaluation and practical interpretability of the resulting segments.

## 7. Expected Segment Interpretation
Depending on the cluster profile, segments can represent groups such as:
- High-value / premium customers
- Regular customers
- Budget or deal-seeking customers
- Low-value or occasional customers

## 8. Business Insights
Customer segmentation can help a business:
- Personalize marketing campaigns.
- Identify high-value customers.
- Design targeted discounts.
- Improve customer retention.
- Recommend products based on behavior.
- Allocate marketing budgets more efficiently.

## 9. Conclusion
The project demonstrates how unsupervised machine learning can transform raw customer data into actionable customer groups. K-Means clustering provides a practical starting point for understanding customer behavior and designing targeted strategies.

## 10. How to Run
Install dependencies:

```bash
pip install pandas numpy matplotlib scikit-learn jupyter
```

Then open:

`Customer_Segmentation_Project.ipynb`

or run:

```bash
python customer_segmentation.py
```

**Note:** The included dataset is a project-ready synthetic dataset created for demonstration and learning. For a real business deployment, replace it with validated customer data and re-evaluate the clusters.
